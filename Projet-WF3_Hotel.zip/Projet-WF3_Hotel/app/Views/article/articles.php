<?php

echo $my_title;


?>



<!--
<ul>
<?php foreach ($daltons as $value):  ?>
<li> <?php echo $value  ?> </li> 
<?php endforeach  ?>
</ul>

-->

<?php

/* autre méthode que dessus :  
<?php foreach ($daltons as $value){ echo '<li>'.$value .'</li>'; }  ?>
*/


?>