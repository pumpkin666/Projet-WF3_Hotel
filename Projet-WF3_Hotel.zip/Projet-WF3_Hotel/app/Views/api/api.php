<?php $this->layout('layout_api', ['title' => 'Trouvez-nous']) ?>

<?php $this->start('main_content') ?>
 <script>  
                    function initialisation(){
                        var optioncarte = {
                            zoom = 8,
                            centre = new google.maps.LatLng(48.836971, 2.334530)
                        }
                        var macarte = new google.maps.Map(document.getElementById("82 avenue Denfert Rocherault"))
                    }  
                    google.maps.event.addDomListener(window, 'load', initialisation);
                </script>

<?php $this->stop('main_content') ?>
                
                